import React from 'react';
import './App.css';
import Header from './components/header/Header';
import Navbar from './components/navbar/Navbar';
import Profile from './components/profile/Profile';
import Dialogs from './components/dialogs/Dialog';
import { BrowserRouter, Route, Routes  } from 'react-router-dom';

function App(props) {
  return (
 <div className='wrapper'>
  <BrowserRouter>
  <Header /> 
  <Navbar />
  <Routes>
    <Route exact path='/' render={()=><Profile  postsData={props.postsData}/>}/>
    <Route exact path='/profile' render={()=><Profile postsData={props.postsData}/>}/>
    <Route exact path='/dialogs'render={()=><Dialogs dialogNames={props.dialogNames} messageItems={props.messageItems}/>}/>
  </Routes>
  </BrowserRouter>
 </div>
  );
}

export default App;
