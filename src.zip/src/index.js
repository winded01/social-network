import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
let dialogNames=[{name:'Иван Иванов', id:1},{name:'Дональд Трамп', id:2},{name:'Билл Гейтс', id:3}];
let messageItems=[{message:'Hello world',id:1},{message:'Hello',id:2},{message:'Hi',id:3}];
let postsData =[{text:'hello world', id:'1', likes:8},{text:'hello', id:'2', likes:3},{text:'im Elon', id:'3', likes:5}];
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App dialogNames={dialogNames} messageItems={messageItems}  postsData={postsData}/>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
